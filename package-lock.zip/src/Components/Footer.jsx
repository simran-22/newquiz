import React from 'react'

const Footer = () => {
  return (
    <div className=' footer-section container-fluid bg-dark'>
      <div className="row">
        <div className="col-sm-12">
        <h1 className=" text-light ">Footer</h1>
        </div>
      </div>
    </div>
  )
}

export default Footer
