import React from 'react'

const Shop = () => {
  return (
    <div className='container'>
    <div className='row'>
      <div className="col-sm-12 text-center p-4">
      <h1> <b> Wel Come To Shop!</b></h1>
      <hr />

      </div>
    </div>
  </div>
  )
}

export default Shop
